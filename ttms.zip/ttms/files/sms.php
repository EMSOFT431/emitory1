<div class="navbar navbar-inverse navbar-fixed-top " id="menu">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>

        </div>
        <div class="navbar-collapse collapse move-me">
            <ul class="nav navbar-nav navbar-left">
                <li>Welcome Lecturer</li>


            </ul><br>

            <ul class="nav navbar-nav navbar-left">

            <li> <a href="Allocationmsg.php">Allocation Info</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li><a href="firstpage.php">LOGOUT</a></li>
            </ul>

        </div>
    </div>
</div>