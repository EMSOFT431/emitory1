<?php
if(isset($_POST['updte'])) {

    $sub = $_POST['select_subject'];

    if(isset($sub)){

        $teachday = $_POST['select_day'];
        $teachperiod = $_POST['period'];
    
        $query = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "SELECT * FROM subjects WHERE `subject_name` = '$sub' ");
    $row = mysqli_fetch_assoc($query);/**fetching subject details */
    $database_name = " semester" . $row['semester'] . " ";
    $subname = $row['subject_name'];
    $allotedto = $row['allotedto'];
    $room = $row['department'];
    
    
    
    if(isset($allotedto)){
    
        /**picking lecturer name from the faculty number */
        $lectname =mysqli_query(mysqli_connect("localhost", "root", "", "ttms"),
        "SELECT * FROM teachers WHERE faculty_number='$allotedto'");
    $row2 = mysqli_fetch_assoc($lectname);
    
    $allotedto = $row2['name'];
    
    
    }
    if($teachday=="Monday" && $teachperiod=="Morning"){
        /**check if classroom already exists in monday morning period */
            $cl1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period1 LIKE '%$subname%' AND day='monday'");
        $r1 = mysqli_fetch_assoc($cl1);
        $c1 = $r1['period1'];
        /**check if lecturer already exists in monday morning period */
        $cll1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period1 LIKE '%$room%' AND day='monday'");
        $rr1 = mysqli_fetch_assoc($cll1);
        $cc1 = $rr1['period1'];
        
         if($c1 && $cc1){
            
            $q1 = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "UPDATE $database_name SET  period1= '".$subname.",".$room.",".$allotedto."<br>" ."' WHERE day='monday' ");
            echo "<script type='text/javascript'>alert('Updated'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
        
        }
        
        else{
            /**Insert values into time table for monday morning */
           
            echo "<script type='text/javascript'>alert('Values dont exist in this period'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
        
        
        }  


    } else if($teachday=="Monday" && $teachperiod=="Afternoon"){
        /**check if classroom already exists in monday morning period */
            $cl1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period3 LIKE '%$subname%' AND day='monday'");
        $r1 = mysqli_fetch_assoc($cl1);
        $c1 = $r1['period3'];
        /**check if lecturer already exists in monday morning period */
        $cll1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period3 LIKE '%$room%' AND day='monday'");
        $rr1 = mysqli_fetch_assoc($cll1);
        $cc1 = $rr1['period3'];
        
         if($c1 && $cc1){
            
            $q1 = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "UPDATE $database_name SET  period3= '".$subname.",".$room.",".$allotedto."<br>" ."' WHERE day='monday' ");
            echo "<script type='text/javascript'>alert('Updated'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
        
        }
        
        else{
            /**Insert values into time table for monday morning */
           
            echo "<script type='text/javascript'>alert('Values dont exist in this period'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
        
        
        }  


    }else if($teachday=="Tuesday" && $teachperiod=="Morning"){
        /**check if classroom already exists in monday morning period */
            $cl1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period1 LIKE '%$subname%' AND day='tuesday'");
        $r1 = mysqli_fetch_assoc($cl1);
        $c1 = $r1['period1'];
        /**check if lecturer already exists in monday morning period */
        $cll1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period1 LIKE '%$room%' AND day='tuesday'");
        $rr1 = mysqli_fetch_assoc($cll1);
        $cc1 = $rr1['period1'];
        
         if($c1 && $cc1){
            
            $q1 = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "UPDATE $database_name SET  period1= '".$subname.",".$room.",".$allotedto."<br>" ."' WHERE day='tuesday' ");
            echo "<script type='text/javascript'>alert('Updated'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
        
        }
        
        else{
            /**Insert values into time table for monday morning */
           
            echo "<script type='text/javascript'>alert('Values dont exist in this period'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
        
        
        }  


    } else if($teachday=="Tuesday" && $teachperiod=="Afternoon"){
        /**check if classroom already exists in monday morning period */
            $cl1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period3 LIKE '%$subname%' AND day='tuesday'");
        $r1 = mysqli_fetch_assoc($cl1);
        $c1 = $r1['period3'];
        /**check if lecturer already exists in monday morning period */
        $cll1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period3 LIKE '%$room%' AND day='tuesday'");
        $rr1 = mysqli_fetch_assoc($cll1);
        $cc1 = $rr1['period3'];
        
         if($c1 && $cc1){
            
            $q1 = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "UPDATE $database_name SET  period3= '".$subname.",".$room.",".$allotedto."<br>" ."' WHERE day='tuesday' ");
            echo "<script type='text/javascript'>alert('Updated'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
        
        }
        
        else{
            /**Insert values into time table for monday morning */
           
            echo "<script type='text/javascript'>alert('Values dont exist in this period'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
        
        
        }  


    } else if($teachday=="Wednesday" && $teachperiod=="Morning"){
        /**check if classroom already exists in monday morning period */
            $cl1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period1 LIKE '%$subname%' AND day='wednesday'");
        $r1 = mysqli_fetch_assoc($cl1);
        $c1 = $r1['period1'];
        /**check if lecturer already exists in monday morning period */
        $cll1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period1 LIKE '%$room%' AND day='wednesday'");
        $rr1 = mysqli_fetch_assoc($cll1);
        $cc1 = $rr1['period1'];
        
         if($c1 && $cc1){
            
            $q1 = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "UPDATE $database_name SET  period1= '".$subname.",".$room.",".$allotedto."<br>" ."' WHERE day='wednesday' ");
            echo "<script type='text/javascript'>alert('Updated'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
        
        }
        
        else{
            /**Insert values into time table for monday morning */
           
            echo "<script type='text/javascript'>alert('Values dont exist in this period'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
        
        
        }  


    } else if($teachday=="Wednesday" && $teachperiod=="Afternoon"){
        /**check if classroom already exists in monday morning period */
            $cl1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period3 LIKE '%$subname%' AND day='wednesday'");
        $r1 = mysqli_fetch_assoc($cl1);
        $c1 = $r1['period3'];
        /**check if lecturer already exists in monday morning period */
        $cll1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period3 LIKE '%$room%' AND day='wednesday'");
        $rr1 = mysqli_fetch_assoc($cll1);
        $cc1 = $rr1['period3'];
        
         if($c1 && $cc1){
            
            $q1 = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "UPDATE $database_name SET  period3= '".$subname.",".$room.",".$allotedto."<br>" ."' WHERE day='wednesday' ");
            echo "<script type='text/javascript'>alert('Updated'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
        
        }
        
        else{
            /**Insert values into time table for monday morning */
           
            echo "<script type='text/javascript'>alert('Values dont exist in this period'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
        
        
        }  


    } else if($teachday=="Thursday" && $teachperiod=="Morning"){
        /**check if classroom already exists in monday morning period */
            $cl1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period1 LIKE '%$subname%' AND day='thursday'");
        $r1 = mysqli_fetch_assoc($cl1);
        $c1 = $r1['period1'];
        /**check if lecturer already exists in monday morning period */
        $cll1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period1 LIKE '%$room%' AND day='thursday'");
        $rr1 = mysqli_fetch_assoc($cll1);
        $cc1 = $rr1['period1'];
        
         if($c1 && $cc1){
            
            $q1 = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "UPDATE $database_name SET  period1= '".$subname.",".$room.",".$allotedto."<br>" ."' WHERE day='thursday' ");
            echo "<script type='text/javascript'>alert('Updated'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
        
        }
        
        else{
            /**Insert values into time table for monday morning */
           
            echo "<script type='text/javascript'>alert('Values dont exist in this period'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
        
        
        }  


    } else if($teachday=="Thursday" && $teachperiod=="Afternoon"){
        /**check if classroom already exists in monday morning period */
            $cl1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period3 LIKE '%$subname%' AND day='thursday'");
        $r1 = mysqli_fetch_assoc($cl1);
        $c1 = $r1['period3'];
        /**check if lecturer already exists in monday morning period */
        $cll1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period3 LIKE '%$room%' AND day='thursday'");
        $rr1 = mysqli_fetch_assoc($cll1);
        $cc1 = $rr1['period3'];
        
         if($c1 && $cc1){
            
            $q1 = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "UPDATE $database_name SET  period3= '".$subname.",".$room.",".$allotedto."<br>" ."' WHERE day='thursday' ");
            echo "<script type='text/javascript'>alert('Updated'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
        
        }
        
        else{
            /**Insert values into time table for monday morning */
           
            echo "<script type='text/javascript'>alert('Values dont exist in this period'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
        
        
        }  


    } else if($teachday=="Friday" && $teachperiod=="Morning"){
        /**check if classroom already exists in monday morning period */
            $cl1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period1 LIKE '%$subname%' AND day='friday'");
        $r1 = mysqli_fetch_assoc($cl1);
        $c1 = $r1['period1'];
        /**check if lecturer already exists in monday morning period */
        $cll1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period1 LIKE '%$room%' AND day='friday'");
        $rr1 = mysqli_fetch_assoc($cll1);
        $cc1 = $rr1['period1'];
        
         if($c1 && $cc1){
            
            $q1 = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "UPDATE $database_name SET  period1= '".$subname.",".$room.",".$allotedto."<br>" ."' WHERE day='friday' ");
            echo "<script type='text/javascript'>alert('Updated'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
        
        }
        
        else{
            /**Insert values into time table for monday morning */
           
            echo "<script type='text/javascript'>alert('Values dont exist in this period'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
        
        
        }  


    } else if($teachday=="Friday" && $teachperiod=="Afternoon"){
        /**check if classroom already exists in monday morning period */
            $cl1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period3 LIKE '%$subname%' AND day='friday'");
        $r1 = mysqli_fetch_assoc($cl1);
        $c1 = $r1['period3'];
        /**check if lecturer already exists in monday morning period */
        $cll1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period3 LIKE '%$room%' AND day='friday'");
        $rr1 = mysqli_fetch_assoc($cll1);
        $cc1 = $rr1['period3'];
        
         if($c1 && $cc1){
            
            $q1 = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "UPDATE $database_name SET  period3= '".$subname.",".$room.",".$allotedto."<br>" ."' WHERE day='friday' ");
            echo "<script type='text/javascript'>alert('Updated'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
        
        }
        
        else{
            /**Insert values into time table for monday morning */
           
            echo "<script type='text/javascript'>alert('Values dont exist in this period'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
        
        
        }  


    } else if($teachday=="Saturday" && $teachperiod=="Morning"){
        /**check if classroom already exists in monday morning period */
            $cl1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period1 LIKE '%$subname%' AND day='saturday'");
        $r1 = mysqli_fetch_assoc($cl1);
        $c1 = $r1['period1'];
        /**check if lecturer already exists in monday morning period */
        $cll1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period1 LIKE '%$room%' AND day='saturday'");
        $rr1 = mysqli_fetch_assoc($cll1);
        $cc1 = $rr1['period1'];
        
         if($c1 && $cc1){
            
            $q1 = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "UPDATE $database_name SET  period1= '".$subname.",".$room.",".$allotedto."<br>" ."' WHERE day='saturday' ");
            echo "<script type='text/javascript'>alert('Updated'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
        
        }
        
        else{
            /**Insert values into time table for monday morning */
           
            echo "<script type='text/javascript'>alert('Values dont exist in this period'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
        
        
        }  


    } else if($teachday=="Saturday" && $teachperiod=="Afternoon"){
        /**check if classroom already exists in monday morning period */
            $cl1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period3 LIKE '%$subname%' AND day='saturday'");
        $r1 = mysqli_fetch_assoc($cl1);
        $c1 = $r1['period3'];
        /**check if lecturer already exists in monday morning period */
        $cll1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period3 LIKE '%$room%' AND day='saturday'");
        $rr1 = mysqli_fetch_assoc($cll1);
        $cc1 = $rr1['period3'];
        
         if($c1 && $cc1){
            
            $q1 = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "UPDATE $database_name SET  period3= '".$subname.",".$room.",".$allotedto."<br>" ."' WHERE day='saturday' ");
            echo "<script type='text/javascript'>alert('Updated'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
        
        }
        
        else{
            /**Insert values into time table for monday morning */
           
            echo "<script type='text/javascript'>alert('Values dont exist in this period'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
        
        
        }  


    } else{

        echo "<script type='text/javascript'>alert('Select correct values'); window.location.href='generatetimetable".$row['semester'].".php'</script>";


    }


    }
}

else{
$sub = $_POST['select_subject'];


if(isset($sub)){

    $teachday = $_POST['select_day'];
    $teachperiod = $_POST['period'];

    $query = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "SELECT * FROM subjects WHERE `subject_name` = '$sub' ");
$row = mysqli_fetch_assoc($query);/**fetching subject details */
$database_name = " semester" . $row['semester'] . " ";
$subname = $row['subject_name'];
$allotedto = $row['allotedto'];
$room = $row['department'];



if(isset($allotedto)){

    /**picking lecturer name from the faculty number */
    $lectname =mysqli_query(mysqli_connect("localhost", "root", "", "ttms"),
    "SELECT * FROM teachers WHERE faculty_number='$allotedto'");
$row2 = mysqli_fetch_assoc($lectname);

$allotedto = $row2['name'];


}



if($teachday=="Monday" && $teachperiod=="Morning"){
/**check if classroom already exists in monday morning period */
    $cl1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period1 LIKE '%$room%' AND day='monday'");
$r1 = mysqli_fetch_assoc($cl1);
$c1 = $r1['period1'];
/**check if lecturer already exists in monday morning period */
$cll1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period1 LIKE '%$allotedto%' AND day='monday'");
$rr1 = mysqli_fetch_assoc($cll1);
$cc1 = $rr1['period1'];

 if($c1){
    
    echo "<script type='text/javascript'>alert('Cannot allocate same Class in same Period Reallocate....'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
  

}else if($cc1){

    echo "<script type='text/javascript'>alert('Cannot allocate same Lecturer in same Period Reallocate....'); window.location.href='generatetimetable".$row['semester'].".php'</script>";

}

else{
    /**Insert values into time table for monday morning */
    $q1 = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "UPDATE $database_name SET  period1= CONCAT(period1,'".$subname.",".$room.",".$allotedto."<br>" ."') WHERE day='monday' ");
$mess = "".$subname." by ".$allotedto." allocated to Monday morning for semester ".$row['semester']."";

$q2 = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "INSERT INTO messages (`Message`) VALUES ('$mess')");

echo "<script type='text/javascript'>alert('Time Table Generated'); window.location.href='generatetimetable".$row['semester'].".php'</script>";


}   

}else if ($teachday=="Monday" && $teachperiod=="Afternoon"){

    /**check if classroom already exists in monday afternoon period */
    $cl1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period3 LIKE '%$room%' AND day='monday'");
    $r1 = mysqli_fetch_assoc($cl1);
    $c1 = $r1['period3'];
    
    /**check if classroom already exists in monday afternoon period */
    $cll1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period3 LIKE '%$allotedto%' AND day='monday'");
    $rr1 = mysqli_fetch_assoc($cll1);
    $cc1 = $rr1['period3'];
    
     if($c1){
        
        echo "<script type='text/javascript'>alert('Cannot allocate same Class in same Period Reallocate....'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
      
    
    }else if($cc1){
    
        echo "<script type='text/javascript'>alert('Cannot allocate same Lecturer in same Period Reallocate....'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
    
    } else{

        /**insert values into time table for monday afternoon*/
    $q1 = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "UPDATE $database_name SET  period3= CONCAT(period3,'". $subname . "," . $room . "," . $allotedto . "<br>" ."') WHERE day='monday' ");
    $mess = "".$subname." by ".$allotedto." allocated to Monday Afternoon for semester ".$row['semester']."";

    $q2 = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "INSERT INTO messages (`Message`) VALUES ('$mess')");
    echo "<script type='text/javascript'>alert('Time Table Generated'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
    }

}else if ($teachday=="Tuesday" && $teachperiod=="Morning"){

    $cl1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period1 LIKE '%$room%' AND day='tuesday'");
    $r1 = mysqli_fetch_assoc($cl1);
    $c1 = $r1['period1'];
    
    $cll1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period1 LIKE '%$allotedto%' AND day='tuesday'");
    $rr1 = mysqli_fetch_assoc($cll1);
    $cc1 = $rr1['period1'];
    
     if($c1){
        
        echo "<script type='text/javascript'>alert('Cannot allocate same Class in same Period Reallocate....'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
      
    
    }else if($cc1){
    
        echo "<script type='text/javascript'>alert('Cannot allocate same Lecturer in same Period Reallocate....'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
    
    }else{

    $q1 = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "UPDATE $database_name SET  period1= CONCAT(period1,'". $subname . "," . $room . "," . $allotedto . "<br>" ."') WHERE day='tuesday' ");
    $mess = "".$subname." by ".$allotedto." allocated to Tuesday morning for semester ".$row['semester']."";

    $q2 = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "INSERT INTO messages (`Message`) VALUES ('$mess')");

    echo "<script type='text/javascript'>alert('Time Table Generated'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
    }

}else if ($teachday=="Tuesday" && $teachperiod=="Afternoon"){

    $cl1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period3 LIKE '%$room%' AND day='tuesday'");
    $r1 = mysqli_fetch_assoc($cl1);
    $c1 = $r1['period3'];
    
    $cll1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period3 LIKE '%$allotedto%' AND day='tuesday'");
    $rr1 = mysqli_fetch_assoc($cll1);
    $cc1 = $rr1['period3'];
    
     if($c1){
        
        echo "<script type='text/javascript'>alert('Cannot allocate same Class in same Period Reallocate....'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
      
    
    }else if($cc1){
    
        echo "<script type='text/javascript'>alert('Cannot allocate same Lecturer in same Period Reallocate....'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
    
    } else{
    $q1 = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "UPDATE $database_name SET  period3= CONCAT(period3,'". $subname . "," . $room . "," . $allotedto . "<br>" ."') WHERE day='tuesday' ");
    $mess = "".$subname." by ".$allotedto." allocated to Tuesday Afternoon for semester ".$row['semester']."";

    $q2 = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "INSERT INTO messages (`Message`) VALUES ('$mess')");

    echo "<script type='text/javascript'>alert('Time Table Generated'); window.location.href='generatetimetable".$row['semester'].".php'</script>";

    }

}else if ($teachday=="Wednesday" && $teachperiod=="Morning"){

    $cl1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period1 LIKE '%$room%' AND day='wednesday'");
    $r1 = mysqli_fetch_assoc($cl1);
    $c1 = $r1['period1'];
    
    $cll1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period1 LIKE '%$allotedto%' AND day='wednesday'");
    $rr1 = mysqli_fetch_assoc($cll1);
    $cc1 = $rr1['period1'];
    
     if($c1){
        
        echo "<script type='text/javascript'>alert('Cannot allocate same Class in same Period Reallocate....'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
      
    
    }else if($cc1){
    
        echo "<script type='text/javascript'>alert('Cannot allocate same Lecturer in same Period Reallocate....'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
    
    }else{


    $q1 = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "UPDATE $database_name SET  period1= CONCAT(period1,'". $subname . "," . $room . "," . $allotedto . "<br>" ."') WHERE day='wednesday' ");
    $mess = "".$subname." by ".$allotedto." allocated to Wednesday morning for semester ".$row['semester']."";

    $q2 = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "INSERT INTO messages (`Message`) VALUES ('$mess')");

    echo "<script type='text/javascript'>alert('Time Table Generated'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
    }

}else if ($teachday=="Wednesday" && $teachperiod=="Afternoon"){

    $cl1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period3 LIKE '%$room%' AND day='wednesday'");
    $r1 = mysqli_fetch_assoc($cl1);
    $c1 = $r1['period3'];
    
    $cll1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period3 LIKE '%$allotedto%' AND day='wednesday'");
    $rr1 = mysqli_fetch_assoc($cll1);
    $cc1 = $rr1['period3'];
    
     if($c1){
        
        echo "<script type='text/javascript'>alert('Cannot allocate same Class in same Period Reallocate....'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
      
    
    }else if($cc1){
    
        echo "<script type='text/javascript'>alert('Cannot allocate same Lecturer in same Period Reallocate....'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
    
    }else{

    $q1 = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "UPDATE $database_name SET  period3= CONCAT(period3,'". $subname . "," . $room . "," . $allotedto . "<br>" ."') WHERE day='wednesday' ");
    $mess = "".$subname." by ".$allotedto." allocated to Wednesday Afternoon for semester ".$row['semester']."";

    $q2 = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "INSERT INTO messages (`Message`) VALUES ('$mess')");

    echo "<script type='text/javascript'>alert('Time Table Generated'); window.location.href='generatetimetable".$row['semester'].".php'</script>";

    }

}else if ($teachday=="Thursday" && $teachperiod=="Morning"){

    $cl1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period1 LIKE '%$room%' AND day='thursday'");
    $r1 = mysqli_fetch_assoc($cl1);
    $c1 = $r1['period1'];
    
    $cll1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period1 LIKE '%$allotedto%' AND day='thursday'");
    $rr1 = mysqli_fetch_assoc($cll1);
    $cc1 = $rr1['period1'];
    
     if($c1){
        
        echo "<script type='text/javascript'>alert('Cannot allocate same Class in same Period Reallocate....'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
      
    
    }else if($cc1){
    
        echo "<script type='text/javascript'>alert('Cannot allocate same Lecturer in same Period Reallocate....'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
    
    } else{

    $q1 = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "UPDATE $database_name SET  period1= CONCAT(period1,'". $subname . "," . $room . "," . $allotedto . "<br>" ."') WHERE day='thursday' ");
    $mess = "".$subname." by ".$allotedto." allocated to Thursday morning for semester ".$row['semester']."";

    $q2 = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "INSERT INTO messages (`Message`) VALUES ('$mess')");

    echo "<script type='text/javascript'>alert('Time Table Generated'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
    }

}else if ($teachday=="Thursday" && $teachperiod=="Afternoon"){

    $cl1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period3 LIKE '%$room%' AND day='thursday'");
    $r1 = mysqli_fetch_assoc($cl1);
    $c1 = $r1['period3'];
    
    $cll1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period3 LIKE '%$allotedto%' AND day='thursday'");
    $rr1 = mysqli_fetch_assoc($cll1);
    $cc1 = $rr1['period3'];
    
     if($c1){
        
        echo "<script type='text/javascript'>alert('Cannot allocate same Class in same Period Reallocate....'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
      
    
    }else if($cc1){
    
        echo "<script type='text/javascript'>alert('Cannot allocate same Lecturer in same Period Reallocate....'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
    
    } else{
    $q1 = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "UPDATE $database_name SET  period3= CONCAT(period3,'". $subname . "," . $room . "," . $allotedto . "<br>" ."') WHERE day='thursday' ");
    $mess = "".$subname." by ".$allotedto." allocated to Thursday Afternoon for semester ".$row['semester']."";

    $q2 = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "INSERT INTO messages (`Message`) VALUES ('$mess')");

    echo "<script type='text/javascript'>alert('Time Table Generated'); window.location.href='generatetimetable".$row['semester'].".php'</script>";

    }

} else if ($teachday=="Friday" && $teachperiod=="Morning"){

    $cl1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period1 LIKE '%$room%' AND day='friday'");
    $r1 = mysqli_fetch_assoc($cl1);
    $c1 = $r1['period1'];
    
    $cll1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period1 LIKE '%$allotedto%' AND day='friday'");
    $rr1 = mysqli_fetch_assoc($cll1);
    $cc1 = $rr1['period1'];
    
     if($c1){
        
        echo "<script type='text/javascript'>alert('Cannot allocate same Class in same Period Reallocate....'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
      
    
    }else if($cc1){
    
        echo "<script type='text/javascript'>alert('Cannot allocate same Lecturer in same Period Reallocate....'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
    
    } else{

    $q1 = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "UPDATE $database_name SET period1= CONCAT(period1,'". $subname . "," . $room . "," . $allotedto . "<br>" ."') WHERE day='friday' ");

    $mess = "".$subname." by ".$allotedto." allocated to Friday morning for semester ".$row['semester']."";

    $q2 = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "INSERT INTO messages (`Message`) VALUES ('$mess')");
    echo "<script type='text/javascript'>alert('Time Table Generated'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
    }

}else if ($teachday=="Friday" && $teachperiod=="Afternoon"){

    $cl1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period3 LIKE '%$room%' AND day='friday'");
    $r1 = mysqli_fetch_assoc($cl1);
    $c1 = $r1['period3'];
    
    $cll1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period3 LIKE '%$allotedto%' AND day='friday'");
    $rr1 = mysqli_fetch_assoc($cll1);
    $cc1 = $rr1['period3'];
    
     if($c1){
        
        echo "<script type='text/javascript'>alert('Cannot allocate same Class in same Period Reallocate....'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
      
    
    }else if($cc1){
    
        echo "<script type='text/javascript'>alert('Cannot allocate same Lecturer in same Period Reallocate....'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
    
    } else{

    $q1 = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "UPDATE $database_name SET  period3= CONCAT(period3,'". $subname . "," . $room . "," . $allotedto . "<br>" ."') WHERE day='friday' ");
    $mess = "".$subname." by ".$allotedto." allocated to Friday Afternoon for semester ".$row['semester']."";

    $q2 = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "INSERT INTO messages (`Message`) VALUES ('$mess')");

    echo "<script type='text/javascript'>alert('Time Table Generated'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
    }
} else if ($teachday=="Saturday" && $teachperiod=="Morning"){

    $cl1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period1 LIKE '%$room%' AND day='saturday'");
    $r1 = mysqli_fetch_assoc($cl1);
    $c1 = $r1['period1'];
    
    $cll1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period1 LIKE '%$allotedto%' AND day='saturday'");
    $rr1 = mysqli_fetch_assoc($cll1);
    $cc1 = $rr1['period1'];
    
     if($c1){
        
        echo "<script type='text/javascript'>alert('Cannot allocate same Class in same Period Reallocate....'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
      
    
    }else if($cc1){
    
        echo "<script type='text/javascript'>alert('Cannot allocate same Lecturer in same Period Reallocate....'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
    
    } else{

    $q1 = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "UPDATE $database_name SET  period1= CONCAT(period1,'". $subname . "," . $room . "," . $allotedto . "<br>" ."') WHERE day='saturday' ");

    $mess = "".$subname." by ".$allotedto." allocated to Saturday morning for semester ".$row['semester']."";

    $q2 = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "INSERT INTO messages (`Message`) VALUES ('$mess')");
    echo "<script type='text/javascript'>alert('Time Table Generated'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
    }

}else if ($teachday=="Saturday" && $teachperiod=="Afternoon"){

    $cl1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period3 LIKE '%$room%' AND day='saturday'");
    $r1 = mysqli_fetch_assoc($cl1);
    $c1 = $r1['period3'];
    
    $cll1 = mysqli_query(mysqli_connect("localhost","root","","ttms"),"SELECT * FROM $database_name WHERE period3 LIKE '%$allotedto%' AND day='saturday'");
    $rr1 = mysqli_fetch_assoc($cll1);
    $cc1 = $rr1['period3'];
    
     if($c1){
        
        echo "<script type='text/javascript'>alert('Cannot allocate same Class in same Period Reallocate....'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
      
    
    }else if($cc1){
    
        echo "<script type='text/javascript'>alert('Cannot allocate same Lecturer in same Period Reallocate....'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
    
    }else{

    $q1 = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "UPDATE $database_name SET  period3= CONCAT(period3,'". $subname . "," . $room . "," . $allotedto . "<br>" ."') WHERE day='saturday' ");
    $mess = "".$subname." by ".$allotedto." allocated to Saturday Afternoon for semester ".$row['semester']."";

    $q2 = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "INSERT INTO messages (`Message`) VALUES ('$mess')");

    echo "<script type='text/javascript'>alert('Time Table Generated'); window.location.href='generatetimetable".$row['semester'].".php'</script>";
    }

}
else{

   


}






}
}

/******redirect back to generate timetable **/
//header("Location:generatetimetable".$row['semester'].".php?success=true");
//header("Location:generatetimetable.php?success=true");

?>