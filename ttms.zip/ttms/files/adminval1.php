<?php


include 'connection.php';
if (isset($_POST['UN']) && isset($_POST['PASS'])) {
    $id = $_POST['UN'];
    $password = $_POST['PASS'];
} else {
    die();
}
$q = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "SELECT * FROM admin WHERE name = '". $id ."' AND password = '".$password."' ");


$row = mysqli_fetch_array($q);
if ($row["usertype"]=="admin") {
   
    header("Location:addteachers.php");
} else if ($row["usertype"]=="student") {
  
   header("Location:facultypage.php");
} 



else {
    $message = "Username and/or Password incorrect.\\nTry again.";
    echo "<script type='text/javascript'>alert('$message');</script>";

}
?>