<?php



$a = mysqli_query(mysqli_connect("localhost","root","","ttms"),"UPDATE semester2 SET period1 = '',period3='' WHERE day = 'tuesday' ");
$b = mysqli_query(mysqli_connect("localhost","root","","ttms"),"UPDATE semester2 SET period1 = '',period3='' WHERE day = 'monday' ");
$c = mysqli_query(mysqli_connect("localhost","root","","ttms"),"UPDATE semester2 SET period1 = '',period3='' WHERE day = 'wednesday' ");
$d = mysqli_query(mysqli_connect("localhost","root","","ttms"),"UPDATE semester2 SET period1 = '',period3='' WHERE day = 'thursday' ");
$e = mysqli_query(mysqli_connect("localhost","root","","ttms"),"UPDATE semester2 SET period1 = '',period3='' WHERE day = 'friday' ");
$f = mysqli_query(mysqli_connect("localhost","root","","ttms"),"UPDATE semester2 SET period1 = '',period3='' WHERE day = 'saturday' ");

$g = mysqli_query(mysqli_connect("localhost","root","","ttms"),"UPDATE semester1 SET period1 = '',period3='' WHERE day = 'tuesday' ");
$h = mysqli_query(mysqli_connect("localhost","root","","ttms"),"UPDATE semester1 SET period1 = '',period3='' WHERE day = 'monday' ");
$i = mysqli_query(mysqli_connect("localhost","root","","ttms"),"UPDATE semester1 SET period1 = '',period3='' WHERE day = 'wednesday' ");
$j = mysqli_query(mysqli_connect("localhost","root","","ttms"),"UPDATE semester1 SET period1 = '',period3='' WHERE day = 'thursday' ");
$k = mysqli_query(mysqli_connect("localhost","root","","ttms"),"UPDATE semester1 SET period1 = '',period3='' WHERE day = 'friday' ");
$l = mysqli_query(mysqli_connect("localhost","root","","ttms"),"UPDATE semester1 SET period1 = '',period3='' WHERE day = 'saturday' ");

$message = "Time tables cleared you can create new ones now.\\nTry again.";
echo "<script type='text/javascript'>alert('$message');</script>";

header("Location:generatetimetable.php");
?>