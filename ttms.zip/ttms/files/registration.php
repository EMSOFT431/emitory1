

<?php

$host = 'localhost';
$un = 'root';
$pass = '';
$db = 'ttms';

$conn = mysqli_connect($host,$un,$pass,$db);

if(!$conn){

 
echo"no conn";


}else{
if(isset($_POST['registerbtn']))
    
$name = $_POST['name'];
$gender = $_POST['gender'];
$registration = $_POST['reg'];
$student = $_POST['stdnt_no'];

$sql = mysqli_query($conn,"INSERT INTO studentreg (Name,Gender,Registration,Studentno) VALUES ('$name','$gender','$registration','$student')");

if($sql){

    $msg = "Registered Successfully.\\nTry again.";
    echo "<script type='text/javascript'>alert('$msg');</script>";
    header("Location:firstpage.php");


}else{

echo"no insert";


}





}



?>