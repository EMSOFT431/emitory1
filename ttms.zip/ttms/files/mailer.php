<?php

$yr = $_POST['select_year'];

if(isset($_POST['year'])){

if($yr=="1"){


    header("Location:generatetimetable1.php?success=true");



}else if($yr==2){


    header("Location:generatetimetable2.php?success=true");



}else if($yr==3){


    header("Location:generatetimetable3.php?success=true");



}

}




?>