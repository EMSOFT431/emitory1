<?php

include 'connection.php';
$id = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"),
"SELECT * FROM messages");

 $row = mysqli_fetch_assoc($id);


$q = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"),
    "DELETE FROM messages WHERE Message = '".$row['Message']."' ");
if ($q) {

    header("Location:teacherclass.php");

} else {
    echo 'Error';
}
?>
