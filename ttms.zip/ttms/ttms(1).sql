-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 15, 2022 at 09:17 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ttms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `usertype` varchar(10) NOT NULL DEFAULT 'user',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `password`, `usertype`) VALUES
(7, 'User', 'ttms123', 'student'),
(6, 'admin', 'pass123', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `classrooms`
--

DROP TABLE IF EXISTS `classrooms`;
CREATE TABLE IF NOT EXISTS `classrooms` (
  `No` int(8) NOT NULL AUTO_INCREMENT,
  `Classname` varchar(15) NOT NULL,
  PRIMARY KEY (`No`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `classrooms`
--

INSERT INTO `classrooms` (`No`, `Classname`) VALUES
(27, 'G4'),
(26, 'D4-1'),
(25, 'F1-A'),
(24, 'F2'),
(23, 'BLOCK-D LAB'),
(22, 'G4-1'),
(28, 'Old Masters lab');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
CREATE TABLE IF NOT EXISTS `messages` (
  `Message` varchar(500) NOT NULL,
  `Allocation_date` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`Message`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `semester1`
--

DROP TABLE IF EXISTS `semester1`;
CREATE TABLE IF NOT EXISTS `semester1` (
  `day` varchar(10) NOT NULL,
  `period1` varchar(500) NOT NULL,
  `period2` varchar(30) NOT NULL,
  `period3` varchar(500) NOT NULL,
  PRIMARY KEY (`day`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `semester1`
--

INSERT INTO `semester1` (`day`, `period1`, `period2`, `period3`) VALUES
('monday', '', '', ''),
('tuesday', '', '-<br>-', ''),
('wednesday', '', '-<br>-', ''),
('thursday', '', '-<br>-', ''),
('friday', '', '-<br>-', ''),
('saturday', '', '-<br>-', '');

-- --------------------------------------------------------

--
-- Table structure for table `semester2`
--

DROP TABLE IF EXISTS `semester2`;
CREATE TABLE IF NOT EXISTS `semester2` (
  `day` varchar(10) NOT NULL,
  `period1` varchar(500) NOT NULL,
  `period2` varchar(30) NOT NULL,
  `period3` varchar(500) NOT NULL,
  PRIMARY KEY (`day`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `semester2`
--

INSERT INTO `semester2` (`day`, `period1`, `period2`, `period3`) VALUES
('monday', '', '-<br>-', ''),
('tuesday', '', '-<br>-', ''),
('wednesday', '', '-<br>-', ''),
('thursday', '', '-<br>-', ''),
('friday', '', '-<br>-', ''),
('saturday', '', '-<br>-', '');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

DROP TABLE IF EXISTS `subjects`;
CREATE TABLE IF NOT EXISTS `subjects` (
  `subject_code` varchar(10) NOT NULL,
  `subject_name` varchar(50) NOT NULL,
  `course_type` varchar(15) NOT NULL,
  `semester` int(1) NOT NULL,
  `Year` int(5) NOT NULL,
  `department` varchar(50) NOT NULL,
  `isAlloted` int(1) NOT NULL,
  `allotedto` text NOT NULL,
  `allotedto2` text NOT NULL,
  `allotedto3` text NOT NULL,
  PRIMARY KEY (`subject_code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`subject_code`, `subject_name`, `course_type`, `semester`, `Year`, `department`, `isAlloted`, `allotedto`, `allotedto2`, `allotedto3`) VALUES
('CS3104', 'Software Development', 'THEORY', 1, 3, 'G4-1', 0, '', '', ''),
('CS3105', 'Visual Basic', 'LAB', 1, 3, 'Old Masters lab', 0, '', '', ''),
('CS2105', 'OOP', 'LAB', 1, 2, 'BLOCK-D LAB', 0, '', '', ''),
('CS3102', 'Systems Admin', 'LAB', 1, 3, 'Old Masters lab', 0, '', '', ''),
('CS2101', 'Operating Systems', 'THEORY', 1, 2, 'Old Masters lab', 0, '', '', ''),
('CS2102', 'Information Security', 'THEORY', 1, 2, 'D4-1', 0, '', '', ''),
('CS1103', 'Christian Ethics', 'THEORY', 1, 1, 'F1-A', 0, '', '', ''),
('CS1105', 'Principles of Programming', 'LAB', 1, 1, 'BLOCK-D LAB', 0, '', '', ''),
('CS1101', 'communication skills', 'THEORY', 1, 1, 'F1-A', 0, '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `t001`
--

DROP TABLE IF EXISTS `t001`;
CREATE TABLE IF NOT EXISTS `t001` (
  `day` varchar(10) NOT NULL,
  `period1` varchar(30) DEFAULT NULL,
  `period2` varchar(30) DEFAULT NULL,
  `period3` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`day`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t001`
--

INSERT INTO `t001` (`day`, `period1`, `period2`, `period3`) VALUES
('monday', '', '', ''),
('tuesday', '', '', ''),
('wednesday', '', '', ''),
('thursday', '', '', ''),
('friday', '', '', ''),
('saturday', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `t002`
--

DROP TABLE IF EXISTS `t002`;
CREATE TABLE IF NOT EXISTS `t002` (
  `day` varchar(10) NOT NULL,
  `period1` varchar(30) DEFAULT NULL,
  `period2` varchar(30) DEFAULT NULL,
  `period3` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`day`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t002`
--

INSERT INTO `t002` (`day`, `period1`, `period2`, `period3`) VALUES
('monday', '', '', ''),
('tuesday', '', '', ''),
('wednesday', '', '', ''),
('thursday', '', '', ''),
('friday', '', '', ''),
('saturday', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `t003`
--

DROP TABLE IF EXISTS `t003`;
CREATE TABLE IF NOT EXISTS `t003` (
  `day` varchar(10) NOT NULL,
  `period1` varchar(30) DEFAULT NULL,
  `period2` varchar(30) DEFAULT NULL,
  `period3` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`day`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t003`
--

INSERT INTO `t003` (`day`, `period1`, `period2`, `period3`) VALUES
('monday', '', '', ''),
('tuesday', '', '', ''),
('wednesday', '', '', ''),
('thursday', '', '', ''),
('friday', '', '', ''),
('saturday', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `t004`
--

DROP TABLE IF EXISTS `t004`;
CREATE TABLE IF NOT EXISTS `t004` (
  `day` varchar(10) NOT NULL,
  `period1` varchar(30) DEFAULT NULL,
  `period2` varchar(30) DEFAULT NULL,
  `period3` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`day`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t004`
--

INSERT INTO `t004` (`day`, `period1`, `period2`, `period3`) VALUES
('monday', '', '', ''),
('tuesday', '', '', ''),
('wednesday', '', '', ''),
('thursday', '', '', ''),
('friday', '', '', ''),
('saturday', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `t005`
--

DROP TABLE IF EXISTS `t005`;
CREATE TABLE IF NOT EXISTS `t005` (
  `day` varchar(10) NOT NULL,
  `period1` varchar(30) DEFAULT NULL,
  `period2` varchar(30) DEFAULT NULL,
  `period3` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`day`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t005`
--

INSERT INTO `t005` (`day`, `period1`, `period2`, `period3`) VALUES
('monday', '', '', ''),
('tuesday', '', '', ''),
('wednesday', '', '', ''),
('thursday', '', '', ''),
('friday', '', '', ''),
('saturday', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `t006`
--

DROP TABLE IF EXISTS `t006`;
CREATE TABLE IF NOT EXISTS `t006` (
  `day` varchar(10) NOT NULL,
  `period1` varchar(30) DEFAULT NULL,
  `period2` varchar(30) DEFAULT NULL,
  `period3` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`day`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t006`
--

INSERT INTO `t006` (`day`, `period1`, `period2`, `period3`) VALUES
('monday', '', '', ''),
('tuesday', '', '', ''),
('wednesday', '', '', ''),
('thursday', '', '', ''),
('friday', '', '', ''),
('saturday', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `t007`
--

DROP TABLE IF EXISTS `t007`;
CREATE TABLE IF NOT EXISTS `t007` (
  `day` varchar(10) NOT NULL,
  `period1` varchar(30) DEFAULT NULL,
  `period2` varchar(30) DEFAULT NULL,
  `period3` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`day`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t007`
--

INSERT INTO `t007` (`day`, `period1`, `period2`, `period3`) VALUES
('monday', '', '', ''),
('tuesday', '', '', ''),
('wednesday', '', '', ''),
('thursday', '', '', ''),
('friday', '', '', ''),
('saturday', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

DROP TABLE IF EXISTS `teachers`;
CREATE TABLE IF NOT EXISTS `teachers` (
  `faculty_number` varchar(10) NOT NULL,
  `name` text NOT NULL,
  `alias` varchar(10) NOT NULL,
  `designation` varchar(30) NOT NULL,
  `contact_number` varchar(15) NOT NULL,
  `emailid` varchar(50) NOT NULL,
  PRIMARY KEY (`faculty_number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`faculty_number`, `name`, `alias`, `designation`, `contact_number`, `emailid`) VALUES
('T001', 'Mukama Kevin', 'MK', 'Lecturer', '+256 756738287', 'Mk@gmail.com'),
('T002', 'Irene Katasi', 'IK', 'Professor', '+256 444455688', 'IrynKa@gmail.com'),
('T003', 'Elon Musk', 'EM', 'Lecturer', '+256 298928378', 'elomusk@gmail.com'),
('T004', 'Tony Stark', 'TS', 'Guest Lecturer', '+256 627838261', 'Tonys@gmail.com'),
('T005', 'Wanyana Allen', 'WA', 'Lecturer', '+256 298928378', 'Wanyana12@gmail.com'),
('T006', 'Lukwago Owen', 'LO', 'Assistant Professor', '+256 847838299', 'Lukowen@gmail.com'),
('T007', 'Jeremy Alekai', 'JA', 'Programming Specialist', '+256 758372638', 'Jeralekai@gmail.com');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
